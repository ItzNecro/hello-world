![LuckyEssentialsLogo](https://i.ibb.co/7Qb9JKh/Lucky-Ess-Logo.png)

# Lucky Essentials

Lucky Essentials is a plugin mainly created to replace EssentialsX's essential features in minigame servers such as /gmc, /fly, /tp, /tphere, /top, etc and also replace some useful plugins in minigame servers such as MYSlots, EasyWhitelist, PlugMan, and ChatLock. I created this because essentials has a lot of useless feature for a minigame server, such as /sethome, /warp, /seen, etc and will only make the server slower/heavier...


* [Wiki](https://github.com/Lucky-Development-Department/LuckyEssentials/wiki)
* [Installation](https://github.com/Lucky-Development-Department/LuckyEssentials/wiki/Installation)
* [Commands and Permissions](https://github.com/Lucky-Development-Department/LuckyEssentials/wiki/Documentation)
